
  <div class="row">
    <div class="col-xs-12 hidden-xs"> <!-- Start Post --> 

      <div class="sorting-wrap">
        <div class="sorting-bar">
          <ul class="primary text-left smooth-button">
            <li>
              <a class="main-tab" href="index.php">USERS</a>
             <ul class="sub">
                <li><a href="index.php">All</a></li>
                <li><a href="index.php?gender=Male">Male</a></li>
                <li><a href="index.php?gender=Female">Female</a></li>
              </ul> 
            </li>
            <li>
              <a class="main-tab" href="dressforless.php">CELEBRITY</a>
              <ul class="sub">
                <li><a href="dressforless.php">All</a></li>
                <li><a href="dressforless.php?gender=Male">Male</a></li>
                <li><a href="dressforless.php?gender=Female">Female</a></li>
              </ul> 
            </li>

            <!-- We will Need these Categories to be Functional 
            <li>
              <a class="main-tab" href="#">Men Casual</a>
            </li> 
            <li>
              <a class="main-tab" href="#">Men Formal</a>
            </li> 
            <li>
              <a class="main-tab" href="#">Women Casual</a>
            </li> 
            <li>
              <a class="main-tab" href="#">Women Formal</a>
            </li>  
            -->     
          </ul>
        </div>
      </div>

    </div> <!-- End Column -->  
  </div>  <!-- End  Sorting Bar --> 