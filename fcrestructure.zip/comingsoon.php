<!--===================== COMING SOON MODAL =================================--> 

<div class="modal fade" id="comingsoon" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content text-center">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Coming Soon</h4>
      </div>
      <div class="modal-body">
        <p> This feature is coming soon.</p>
      </div>
    </div>

  </div>
</div>
