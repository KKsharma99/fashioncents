<?php

if(!defined('INCLUDE_CHECK')) {
	header("Location: 404.php");
	exit();
}
include('header.php');
session_start();

include('connect.php');

if (empty($_SESSION['id'])) {
	header("Location: 404.php");
}

include('nav.php');
