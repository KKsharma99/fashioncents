<div class="row the-main-slider" > <!-- MAIN SLIDER -->
	<div class="col-xs-12 jssor-column-fix">

		<!-- #region Jssor Slider Begin -->
		<script src="js/jssor.slider-23.1.6.min.js" type="text/javascript">
		</script>
		<script type="text/javascript">
			jssor_1_slider_init = function() {

				var jssor_1_SlideoTransitions = [
				[{b:900,d:2000,x:-379,e:{x:7}}],
				[{b:900,d:2000,x:-379,e:{x:7}}],
				[{b:-1,d:1,o:-1,sX:2,sY:2},{b:0,d:900,x:-171,y:-341,o:1,sX:-2,sY:-2,e:{x:3,y:3,sX:3,sY:3}},{b:900,d:1600,x:-283,o:-1,e:{x:16}}]
				];

				var jssor_1_options = {
					$AutoPlay: 1,
					$SlideDuration: 800,
					$SlideEasing: $Jease$.$OutQuint,
					$CaptionSliderOptions: {
						$Class: $JssorCaptionSlideo$,
						$Transitions: jssor_1_SlideoTransitions
					},
					$ArrowNavigatorOptions: {
						$Class: $JssorArrowNavigator$
					},
					$BulletNavigatorOptions: {
						$Class: $JssorBulletNavigator$
					}
				};

				var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

				/*responsive code begin*/
				/*remove responsive code if you don't want the slider scales while window resizing*/
				function ScaleSlider() {
					var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
					if (refSize) {
						refSize = Math.min(refSize, 1920);
						jssor_1_slider.$ScaleWidth(refSize);
					}
					else {
						window.setTimeout(ScaleSlider, 30);
					}
				}
				ScaleSlider();
				$Jssor$.$AddEvent(window, "load", ScaleSlider);
				$Jssor$.$AddEvent(window, "resize", ScaleSlider);
				$Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
				/*responsive code end*/
			};
		</script>
		<style>
			.jssorb05 {
				position: absolute;
			}

			.jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
				position: absolute;
				/* size of bullet elment */
				width: 16px;
				height: 16px;
				background: url('img/b05.png') no-repeat;
				overflow: hidden;
				cursor: pointer;
			}
			.jssorb05 div { background-position: -7px -7px; }
			.jssorb05 div:hover, .jssorb05 .av:hover { background-position: -37px -7px; }
			.jssorb05 .av { background-position: -67px -7px; }
			.jssorb05 .dn, .jssorb05 .dn:hover { background-position: -97px -7px; }

			.jssora22l, .jssora22r {
				display: block;
				position: absolute;
				/* size of arrow element */
				width: 40px;
				height: 58px;
				cursor: pointer;
				background: url('img/a22.png') center center no-repeat;
				overflow: hidden;
			}
			.jssora22l { background-position: -10px -31px; }
			.jssora22r { background-position: -70px -31px; }
			.jssora22l:hover { background-position: -130px -31px; }
			.jssora22r:hover { background-position: -190px -31px; }
			.jssora22l.jssora22ldn { background-position: -250px -31px; }
			.jssora22r.jssora22rdn { background-position: -310px -31px; }
			.jssora22l.jssora22lds { background-position: -10px -31px; opacity: .3; pointer-events: none; }
			.jssora22r.jssora22rds { background-position: -70px -31px; opacity: .3; pointer-events: none; }
		</style>

		<div id="jssor_1" class="jssor_1-style">
			<!-- Loading Screen -->
			<div data-u="loading" style="position:absolute;top:0px;left:0px;background:url('img/loading.gif') no-repeat 50% 50%;background-color:rgba(0, 0, 0, 0.7);">
			</div>

			<div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1300px;height:500px;overflow:hidden;">
				<div>
					<img data-u="image" src="img/slide1.jpg"/>
				</div>
				<div >
					<img data-u="image" src="img/slide2.jpg"  />
				</div>
				<div>
					<img data-u="image" src="img/slide3.jpg" />
				</div>
				<a data-u="any" href="https://www.jssor.com/wordpress.html" style="display:none">
					blank
				</a>
			</div>
			<!-- Bullet Navigator -->
			<div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
				<!-- bullet navigator item prototype -->
				<div data-u="prototype" style="width:16px;height:16px;">
				</div>
			</div>
			<!-- Arrow Navigator -->
			<span data-u="arrowleft" class="jssora22l" style="top:0px;left:55px;width:40px;height:58px;" data-autocenter="2">
			</span>
			<span data-u="arrowright" class="jssora22r" style="top:0px;right:8px;width:40px;height:58px;" data-autocenter="2">
			</span>
		</div>
		<script type="text/javascript">jssor_1_slider_init();
		</script>
		<!-- #endregion Jssor Slider End --> 


	</div> <!-- End Column -->
</div> <!-- End Row --> 

<div class="row text-center"> <!-- WHY SHOP AT FC LABEL? -->

	<div class="col-xs-12">

		<h1 class="landing-headers2"> Why Shop at Fashioncents?
		</h1>

	</div> <!-- FOUR REASONS --> 
</div> <!-- End Row -->

<div class="row text-center"> <!-- FOUR REASONS --> 

	<div class="col-xs-12 col-md-6 col-lg-3">

		<div class="feature-item">

			<img class="landingpage-icon" src="vendor/custom-icons/idea.png">

			<h3>Shop Inspiration
			</h3>

			<p class="text-muted" style="font-size: 14px; color: darkgrey; letter-spacing: 1.1px">
				We deliver fashionable outfits from around the world 
				right to your personalized feed. The moment you fall in love with a look, you can buy the
				items you see. See it, Like it, Buy it. 
			</p>

		</div>
	</div> <!-- End Column -->

	<div class="col-xs-12 col-md-6 col-lg-3">

		<div class="feature-item">

			<img class="landingpage-icon" src="vendor/custom-icons/money2.png">

			<h3>Social Context
			</h3>

			<p class="text-muted" style="font-size: 14px; color: darkgrey; letter-spacing: 1.1px">
				Know what's trending. With shoppable outfits ranging from everday individuals to red-carpet celebrities,
				we make it easy to learn how the community pieces together stylish outfits.
			</p>

		</div>
	</div> <!-- End Column -->

	<div class="col-xs-12 col-md-6 col-lg-3">
		<div class="feature-item">
			<img class="landingpage-icon" src="vendor/custom-icons/network2.png">

			<h3>Simple and Personal
			</h3>

			<p class="text-muted" style="font-size: 14px; color: darkgrey; letter-spacing: 1.1px">
				By shopping in the context of outfits, we save you the time and frustation that goes 
				into building a stylish wardrobe that represents you.
			</p>
		</div>
	</div> <!-- End Column --> 

	<div class="col-xs-12 col-md-6 col-lg-3">

		<div class="feature-item">

			<img class=" landingpage-icon" src="vendor/custom-icons/heart2.png">

			<h3>Confidence
			</h3>                

			<p class="text-muted" style="font-size: 14px; color: darkgrey; letter-spacing: 1.1px">
				When your outfits match your style, you will come off as more confident, attractive and impressive to those around you. You deserve
				to look and feel your best.
			</p>

		</div>
	</div> <!-- End Column -->  
</div> <!-- End Row -->

<div class="row text-center"> <!-- TOP PARTNERS LABEL --> 

	<div class="col-xs-12">

		<h1 class="landing-headers">Top Partners
		</h1>

	</div> <!-- End Column -->  
</div> <!-- End Row --> 

<div class="row"> <!-- BRANDS PART 1 --> 

	<div class="col-md-1 col-xs-4">
		<img src="img/brands/1.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/2.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/3.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/4.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/5.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/6.png" class="img-responsive brand-logo"> 
	</div>

	<div class="col-md-1 col-xs-4">
		<img src="img/brands/7.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/8.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/9.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/10.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/11.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/12.jpg" class="img-responsive brand-logo"> 
	</div> 
</div> <!-- End Row --> 

<div class="row"> <!-- BRANDS PART 2 -->

	<div class="col-md-1 col-xs-4">
		<img src="img/brands/13.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/14.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/15.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/16.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/17.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/18.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/19.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/20.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/21.png" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/22.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/23.jpg" class="img-responsive brand-logo"> 
	</div>
	<div class="col-md-1 col-xs-4">
		<img src="img/brands/24.jpg" class="img-responsive brand-logo"> 
	</div>
</div> <!-- End Row --> 

<div class="row"> <!-- HOW IT WORKS LABEL -->
	<div class="col-xs-12 text-center">

		<h1 class="landing-headers3">How it Works?</h1>

	</div>
</div>  <!-- End Row --> 

<div class="row text-center"> <!-- HOW IT WORKS IMAGES -->
	<div class="col-xs-12 col-md-12">

		<img src="img/earn2.png" class="img-responsive hidden-xs" width="100%">
		<img src="img/earn-m-1.png" class="img-responsive visible-xs" width="100%"> 
		<img src="img/earn-m-2.png" class="img-responsive visible-xs" width="100%">
		<img src="img/earn-m-3.png" class="img-responsive visible-xs" width="50%"> 

	</div> 
</div> <!-- End Row -->

<div class="row"> <!-- TRENDING POSTS LABEL -->
	<div class="col-xs-12 text-center">

		<h1 class="landing-headers3">Trending Posts</h1>
		<br> <br>

	</div>
</div>  <!-- End Row --> 

<div class="row"> <!-- TRENDING POSTS EXAMPLES -->
	<!--============== Start Post =========================--> 
	<div class="col-lg-4"> 
		<div class="panel panel-white post panel-shadow">

			<div class="post-heading">

				<div class="pull-left image">
					<a href="account.php?userid=527">
						<img src="img/sample/1.0.png" class="img-circle avatar" alt="img/users/defaultuser.jpg">
					</a>
				</div> <!-- User Avatar --> 

				<div class="pull-left">
					<div class="post-user">
						<a href="#"><b>Taylor Matkovic</b></a>
					</div>
				</div> <!-- User Name --> 

				<div class="dropdown">

					<btn id="follow527" class="dropdown-toggle" type="button" data-toggle="dropdown"><img data-toggle="tooltip" title="OPTIONS" src="vendor/custom-icons/dots-v.png" class="dots-v pull-right"></btn>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Share</a></li>
						<li class="dropdown-header">Report</li>
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Explicit Content</a></li>
						<li><a onclick='showErrorModal("har",405);' data-toggle="modal" data-target="#errorconfim">Harassment</a></li>
						<li><a onclick='showErrorModal("copyr",405);' data-toggle="modal" data-target="#errorconfim">Copyright Violation</a></li>
					</ul> <!-- End Dropdown Menu --> 
				</div> <!-- End Dropdown --> 

				<img data-toggle="tooltip" title="FOLLOW" id="follow527" name="follow527" src="vendor/custom-icons/circle-plus.png" class="circle-plus pull-right" onclick = "follow(527 , 2, 3)">
				<div class="pull-right">
					<h6 class="text-muted post-time">2W</h6>
				</div>
			</div> <!--sn End Post Heading --> 

			<div class="post-description bottom-padding"> 
				<a href="userpost.php?postid=405">
					<img class="img-responsive text-center" width="100%" src="img/sample/1.png" alt="test">
				</a>

				<div class="new-interact-bar"> 

					<!-- This Script Initializes the Tooltips --> 
					<script> 
						$(document).ready(function(){
							$('[data-toggle="tooltip"]').tooltip(); 
						});
					</script>
					<!-- End Tooltip Initializing Script -->

					<span class="pull-left"> <!-- Reaction Section -->
						<div data-toggle="tooltip" title="53 Reactions" class="btn btn-sm total-reacts-btn"><strong>53</strong></div>
						<img  data-toggle="tooltip" title="LOVE" src="vendor/custom-icons/in-love-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="COOL" src="vendor/custom-icons/cool-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="WOW" src="vendor/custom-icons/surprised-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="CUTE" src="vendor/custom-icons/kiss-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="ENVY" src="vendor/custom-icons/angry-inactive.png" class="emoj-reacts">
					</span> 

					<span class="pull-right"> <!-- Post Option Section --> 
						<img  aria-controls="addComment" aria-expanded="false" data-target="#addComment" data-toggle="collapse"
						data-toggle="tooltip" title="COMMENT" src="vendor/custom-icons/comment.png" class="post-options">
						<img  data-toggle="tooltip" title="SAVE" src="vendor/custom-icons/bookmark.png" class="post-options">
					</span> 
				</div>
			</div> <!-- End Post Description --> 

			<div class="post-footer new-post-footer">
				<ul>
					<li class="text-center">
						<img data-toggle="tooltip" title="Previous Comments (6)" src="vendor/custom-icons/dots-h.png" class="dots-h"> 
					</li>
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart.png" class="heart-icon"> 
							<a href="#">Sarah Williams
							</a> What a beautiful outfit! 
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">2w</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">Monica Grant
							</a> Love the Links!
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">30m</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">James Arnold
							</a> If only my GF dressed like you...  
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">5m</span>
						</p>
					</li> 
				</ul> 

				<div class="collapse" id="addComment">
					<input type='text' placeholder='Press "Enter" to Comment'></input>
				</div> <!-- End Add Comment Section --> 
			</div> <!-- End Post Footer --> 

			<div class="dflpost">
				<div class="dflpost-footer">
					<ul class="products-list">

						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://oldnavy.gap.com/browse/product.do?pid=440522012&CAWELAID=120299900000127120&CAGPSPN=pla&CAAGID=36024990456&CATCI=pla-61561028216&cvosrc=cse.google.PLA_Nonbrand&cvo_campaign=691125975&cvo_adgroup=36024990456&cvo_crid=155131028364&Matchtype=&tid=onpl000017&kwid=1&ap=7&gclid=CKvRpaqD5dMCFQmRfgodn0oHRg">
								<img class="img-rounded avatar" src="img/sample/1.1.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://oldnavy.gap.com/browse/product.do?pid=440522012&CAWELAID=120299900000127120&CAGPSPN=pla&CAAGID=36024990456&CATCI=pla-61561028216&cvosrc=cse.google.PLA_Nonbrand&cvo_campaign=691125975&cvo_adgroup=36024990456&cvo_crid=155131028364&Matchtype=&tid=onpl000017&kwid=1&ap=7&gclid=CKvRpaqD5dMCFQmRfgodn0oHRg">
								<button type="button" class="btn btn-sm btn-success buy-button">$40.00</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Trench Coat for Women</p>
									<p class="item-brand">Old Navy</p>
									<p class="item-merchant">GAP</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.charlotterusse.com/ponte-open-back-crop-top/302308796.html?cid=ps:nonbrand:Google&product_id=302308796&adpos=1o13&creative=78709322104&device=c&matchtype=&network=g&gclid=CLf137KD5dMCFZCJfgodMQgE_Q">
								<img class="img-rounded avatar" src="img/sample/1.2.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.charlotterusse.com/ponte-open-back-crop-top/302308796.html?cid=ps:nonbrand:Google&product_id=302308796&adpos=1o13&creative=78709322104&device=c&matchtype=&network=g&gclid=CLf137KD5dMCFZCJfgodMQgE_Q">
								<button type="button" class="btn btn-sm btn-success buy-button">$9.99</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Ponte Open Back Crop Top</p>
									<p class="item-brand">Charlotte Russe</p>
									<p class="item-merchant">Charlotte Russe</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.stance.com/shop/higgs">
								<img class="img-rounded avatar" src="img/sample/1.3.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.stance.com/shop/higgs">
								<button type="button" class="btn btn-sm btn-success buy-button">$59.95</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Shredded Low-Rise Skinny Jeans</p>
									<p class="item-brand">Hollister</p>
									<p class="item-merchant">Hollister</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.amazon.com/dp/B0092AJQDG/">
								<img class="img-rounded avatar" src="img/sample/1.4.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.amazon.com/dp/B0092AJQDG/">
								<button type="button" class="btn btn-sm btn-success buy-button">$159.51</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Brown Leather Ankle Boot</p>
									<p class="item-brand">Hudson Horrigan</p>
									<p class="item-merchant">Daniel Footwear</p>
								</div>
							</div>
						</li>
					</ul>
				</div> <!-- End DFL post footer --> 
			</div> <!-- End DFL Post --> 

		</div> <!-- End Post -->
	</div> <!-- End Column --> 
	<!--============== End Post =========================--> 


	<!--============== Start Post =========================--> 
	<div class="col-lg-4"> 
		<div class="panel panel-white post panel-shadow">

			<div class="post-heading">

				<div class="pull-left image">
					<a href="account.php?userid=527">
						<img src="img/sample/2.0.png" class="img-circle avatar" alt="Sample Image">
					</a>
				</div> <!-- User Avatar --> 

				<div class="pull-left">
					<div class="post-user">
						<a href="account.php?userid=527"><b>Marcela Martinez</b></a>
					</div>
				</div> <!-- User Name --> 

				<div class="dropdown">

					<btn id="follow527" class="dropdown-toggle" type="button" data-toggle="dropdown"><img data-toggle="tooltip" title="OPTIONS" src="vendor/custom-icons/dots-v.png" class="dots-v pull-right"></btn>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Share</a></li>
						<li class="dropdown-header">Report</li>
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Explicit Content</a></li>
						<li><a onclick='showErrorModal("har",405);' data-toggle="modal" data-target="#errorconfim">Harassment</a></li>
						<li><a onclick='showErrorModal("copyr",405);' data-toggle="modal" data-target="#errorconfim">Copyright Violation</a></li>
					</ul> <!-- End Dropdown Menu --> 
				</div> <!-- End Dropdown --> 

				<img data-toggle="tooltip" title="FOLLOW" id="follow527" name="follow527" src="vendor/custom-icons/circle-plus.png" class="circle-plus pull-right" onclick = "follow(527 , 2, 3)">
				<div class="pull-right">
					<h6 class="text-muted post-time">2D</h6>
				</div>
			</div> <!-- End Post Heading --> 

			<div class="post-description bottom-padding"> 
				<a href="userpost.php?postid=405">
					<img class="img-responsive text-center" width="100%" src="img/sample/2.png" alt="test">
				</a>

				<div class="new-interact-bar"> 

					<!-- This Script Initializes the Tooltips --> 
					<script> 
						$(document).ready(function(){
							$('[data-toggle="tooltip"]').tooltip(); 
						});
					</script>
					<!-- End Tooltip Initializing Script -->

					<span class="pull-left"> <!-- Reaction Section -->

						<div data-toggle="tooltip" title="47 Reactions" class="btn btn-sm total-reacts-btn"><strong>47</strong></div>
						<img  data-toggle="tooltip" title="LOVE" src="vendor/custom-icons/in-love-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="COOL" src="vendor/custom-icons/cool-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="WOW" src="vendor/custom-icons/surprised-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="SEXY" src="vendor/custom-icons/kiss-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="ENVY" src="vendor/custom-icons/angry-inactive.png" class="emoj-reacts">
					</span> 

					<span class="pull-right"> <!-- Post Option Section --> 
						<img  aria-controls="addComment" aria-expanded="false" data-target="#addComment" data-toggle="collapse"
						data-toggle="tooltip" title="COMMENT" src="vendor/custom-icons/comment.png" class="post-options">
						<img  data-toggle="tooltip" title="SAVE" src="vendor/custom-icons/bookmark.png" class="post-options">
					</span> 
				</div>
			</div> <!-- End Post Description --> 

			<div class="post-footer new-post-footer">
				<ul>
					<li class="text-center">
						<img data-toggle="tooltip" title="Previous Comments (8)" src="vendor/custom-icons/dots-h.png" class="dots-h"> 
					</li>
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">Adam Westcoff
							</a> Sick background! lol
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">1D</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart.png" class="heart-icon"> 
							<a href="#">Nadia Su
							</a> I definitely need that belt.
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">1D</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">Kathy Vayle
							</a> OMG, luv it.
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">1D</span>
						</p>
					</li> 
				</ul> 

				<div class="collapse" id="addComment">
					<input type='text' placeholder='Press "Enter" to Comment'></input>
				</div> <!-- End Add Comment Section --> 
			</div> <!-- End Post Footer --> 

			<div class="dflpost">
				<div class="dflpost-footer">
					<ul class="products-list">

						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.woolrich.com/woolrich/details/women-s-chambray-shirt/_/R-24179?countryCode=US&trackingCode=googlebase&mr:trackingCode=50B77096-813E-E411-B525-001B2163195C&mr:referralID=NA&mr:device=c&mr:adType=pla_with_promotiononline&mr:ad=90563241864&mr:keyword=&mr:match=&mr:tid=pla-58089879026&mr:ploc=9032047&mr:iloc=&mr:store=&mr:filter=58089879026&gclid=CKebg7L35NMCFYeUfgodt44IEQ">
								<img class="img-rounded avatar" src="img/sample/2.1.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.woolrich.com/woolrich/details/women-s-chambray-shirt/_/R-24179?countryCode=US&trackingCode=googlebase&mr:trackingCode=50B77096-813E-E411-B525-001B2163195C&mr:referralID=NA&mr:device=c&mr:adType=pla_with_promotiononline&mr:ad=90563241864&mr:keyword=&mr:match=&mr:tid=pla-58089879026&mr:ploc=9032047&mr:iloc=&mr:store=&mr:filter=58089879026&gclid=CKebg7L35NMCFYeUfgodt44IEQ">
								<button type="button" class="btn btn-sm btn-success buy-button">$19.99</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name"> Women's Chmabray Shirt</p>
									<p class="item-brand">Woolrich</p>
									<p class="item-merchant">Woolrich</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.hm.com/us/product/47110?gclid=CMGA07j35NMCFUNcfgody9IKQQ&article=47110-H&CAGPSPN=pla&CAAGID=10029219597&CATCI=pla-357949360517&s_kwcid=AL!860!3!46030674837!!!g!357949360517!&ef_id=WRLNnAAAAepXhUk4:20170510084323:s&irgwc=1&clickid=zWEQtpy9sXFFzp4VOI3qNXkhUkhTRZ3OSVFiV00&iradid=226427&utm_content=VigLink-27795&utm_campaign=Online%20Tracking%20Link&iradtype=ONLINE_TRACKING_LINK&irmpname=VigLink&irmptype=mediapartner&utm_medium=affiliate&utm_source=ir">
								<img class="img-rounded avatar" src="img/sample/2.2.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.hm.com/us/product/47110?gclid=CMGA07j35NMCFUNcfgody9IKQQ&article=47110-H&CAGPSPN=pla&CAAGID=10029219597&CATCI=pla-357949360517&s_kwcid=AL!860!3!46030674837!!!g!357949360517!&ef_id=WRLNnAAAAepXhUk4:20170510084323:s&irgwc=1&clickid=zWEQtpy9sXFFzp4VOI3qNXkhUkhTRZ3OSVFiV00&iradid=226427&utm_content=VigLink-27795&utm_campaign=Online%20Tracking%20Link&iradtype=ONLINE_TRACKING_LINK&irmpname=VigLink&irmptype=mediapartner&utm_medium=affiliate&utm_source=ir">
								<button type="button" class="btn btn-sm btn-success buy-button">$14.99</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Super Skinny High Jeggings</p>
									<p class="item-brand">H&M</p>
									<p class="item-merchant">H&M</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.target.com/p/women-s-wide-messy-knot-belt-brown-s-mossimo-supply-co-153/-/A-50866132?ref=tgt_adv_XS000000&AFID=google_pla_df&CPNG=PLA_Accessories">
								<img class="img-rounded avatar" src="img/sample/2.3.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.target.com/p/women-s-wide-messy-knot-belt-brown-s-mossimo-supply-co-153/-/A-50866132?ref=tgt_adv_XS000000&AFID=google_pla_df&CPNG=PLA_Accessories">
								<button type="button" class="btn btn-sm btn-success buy-button">$26.99</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Messy Knot Belt</p>
									<p class="item-brand">Mossimo Supply</p>
									<p class="item-merchant">Mossimo Supply</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="https://www.macys.com/shop/product/steve-madden-donddi-flat-sandals?ID=1977872&pla_country=US&CAGPSPN=pla&CAWELAID=120156340001584477&CAAGID=21585536110&CATCI=pla-320413091404&cm_mmc=Google_Womens_Shoes_PLA-_-G_WS_PLA&LinkshareID=je6NUbpObpQ-kilZ6.LElgXwZF4D3fEx.A">
								<img class="img-rounded avatar" src="img/sample/2.4.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="https://www.macys.com/shop/product/steve-madden-donddi-flat-sandals?ID=1977872&pla_country=US&CAGPSPN=pla&CAWELAID=120156340001584477&CAAGID=21585536110&CATCI=pla-320413091404&cm_mmc=Google_Womens_Shoes_PLA-_-G_WS_PLA&LinkshareID=je6NUbpObpQ-kilZ6.LElgXwZF4D3fEx.A">
								<button type="button" class="btn btn-sm btn-success buy-button">$41.30</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Donddi Flat Sandals</p>
									<p class="item-brand">Steve Madden</p>
									<p class="item-merchant">Macy's</p>
								</div>
							</div>
						</li>
					</ul>
				</div> <!-- End DFL post footer --> 
			</div> <!-- End DFL Post --> 

		</div> <!-- End Post -->
	</div> <!-- End Column --> 
	<!--============== End Post =========================--> 

	<!--============== Start Post =========================--> 
	<div class="col-lg-4"> 
		<div class="panel panel-white post panel-shadow">

			<div class="post-heading">

				<div class="pull-left image">
					<a href="account.php?userid=527">
						<img src="img/sample/3.0.png" class="img-circle avatar" alt="img/users/defaultuser.jpg">
					</a>
				</div> <!-- User Avatar --> 

				<div class="pull-left">
					<div class="post-user">
						<a href="account.php?userid=527"><b>Jarrod Alms</b></a>
					</div>
				</div> <!-- User Name --> 

				<div class="dropdown">

					<btn id="follow527" class="dropdown-toggle" type="button" data-toggle="dropdown"><img data-toggle="tooltip" title="OPTIONS" src="vendor/custom-icons/dots-v.png" class="dots-v pull-right"></btn>

					<ul class="dropdown-menu dropdown-menu-right">
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Share</a></li>
						<li class="dropdown-header">Report</li>
						<li><a onclick='showErrorModal("exp", 405);' data-toggle="modal" data-target="#errorconfim">Explicit Content</a></li>
						<li><a onclick='showErrorModal("har",405);' data-toggle="modal" data-target="#errorconfim">Harassment</a></li>
						<li><a onclick='showErrorModal("copyr",405);' data-toggle="modal" data-target="#errorconfim">Copyright Violation</a></li>
					</ul> <!-- End Dropdown Menu --> 
				</div> <!-- End Dropdown --> 

				<img data-toggle="tooltip" title="FOLLOW" id="follow527" name="follow527" src="vendor/custom-icons/circle-plus.png" class="circle-plus pull-right" onclick = "follow(527 , 2, 3)">
				<div class="pull-right">
					<h6 class="text-muted post-time">2W</h6>
				</div>
			</div> <!-- End Post Heading --> 

			<div class="post-description bottom-padding"> 
				<a href="userpost.php?postid=405">
					<img class="img-responsive text-center" width="100%" src="img/sample/3.png" alt="test">
				</a>

				<div class="new-interact-bar"> 

					<!-- This Script Initializes the Tooltips --> 
					<script> 
						$(document).ready(function(){
							$('[data-toggle="tooltip"]').tooltip(); 
						});
					</script>
					<!-- End Tooltip Initializing Script -->

					<span class="pull-left"> <!-- Reaction Section -->

						<div data-toggle="tooltip" title="62 Reactions" class="btn btn-sm total-reacts-btn"><strong>62</strong></div>
						<img  data-toggle="tooltip" title="LOVE" src="vendor/custom-icons/in-love-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="COOL" src="vendor/custom-icons/cool-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="WOW" src="vendor/custom-icons/surprised-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="SEXY" src="vendor/custom-icons/kiss-inactive.png" class="emoj-reacts">
						<img  data-toggle="tooltip" title="ENVY" src="vendor/custom-icons/angry-inactive.png" class="emoj-reacts">
					</span> 

					<span class="pull-right"> <!-- Post Option Section --> 
						<img  aria-controls="addComment" aria-expanded="false" data-target="#addComment" data-toggle="collapse"
						data-toggle="tooltip" title="COMMENT" src="vendor/custom-icons/comment.png" class="post-options">
						<img  data-toggle="tooltip" title="SAVE" src="vendor/custom-icons/bookmark.png" class="post-options">
					</span> 
				</div>
			</div> <!-- End Post Description --> 

			<div class="post-footer new-post-footer">
				<ul>
					<li class="text-center">
						<img data-toggle="tooltip" title="Previous Comments (6)" src="vendor/custom-icons/dots-h.png" class="dots-h"> 
					</li>
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart.png" class="heart-icon"> 
							<a href="#">Aditi Rajan
							</a> What a stud.
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">2w</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">Grant Calamas
							</a> Good Look bro, just followed.
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">30m</span>
						</p>
					</li> 
					<li>
						<p>
							<img data-toggle="tooltip" title="LIKE" src="vendor/custom-icons/heart2.png" class="heart-icon"> 
							<a href="#">Priya Sharma
							</a> My bae dress that way lol. It's nice. 
							<img data-toggle="tooltip" title="REPORT" src="vendor/custom-icons/warning.png" class="warning-icon pull-right"> 
							<span class="pull-right comment-date">5m</span>
						</p>
					</li> 
				</ul> 

				<div class="collapse" id="addComment">
					<input type='text' placeholder='Press "Enter" to Comment'></input>
				</div> <!-- End Add Comment Section --> 
			</div> <!-- End Post Footer --> 

			<div class="dflpost">
				<div class="dflpost-footer">
					<ul class="products-list">

						<li class="product-item">
							<a class="pull-left" target="_blank" href="https://www.macys.com/shop/product/lauren-ralph-lauren-mens-solid-classic-fit-sport-coat?ID=3005443&pla_country=US&CAGPSPN=pla&CAWELAID=120156340005713321&CAAGID=17673028625&CATCI=pla-117380055185&cm_mmc=Google_Mens_PLA-_-Men%27s&LinkshareID=je6NUbpObpQ-xpsNRn7jhIOmDgrV2WRnuA">
								<img class="img-rounded avatar" src="img/sample/3.1.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="https://www.macys.com/shop/product/lauren-ralph-lauren-mens-solid-classic-fit-sport-coat?ID=3005443&pla_country=US&CAGPSPN=pla&CAWELAID=120156340005713321&CAAGID=17673028625&CATCI=pla-117380055185&cm_mmc=Google_Mens_PLA-_-Men%27s&LinkshareID=je6NUbpObpQ-xpsNRn7jhIOmDgrV2WRnuA">
								<button type="button" class="btn btn-sm btn-success buy-button">$99.99</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name"> Men Solid Classic-Fit Sport Coat</p>
									<p class="item-brand">Ralph Lauren</p>
									<p class="item-merchant">Macy's</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://us.asos.com/asos/asos-tassel-loafers-in-black-faux-suede-with-fringe/prd/7285077?&affid=14174&channelref=product">
								<img class="img-rounded avatar" src="img/sample/3.2.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://us.asos.com/asos/asos-tassel-loafers-in-black-faux-suede-with-fringe/prd/7285077?&affid=14174&channelref=product">
								<button type="button" class="btn btn-sm btn-success buy-button">$45.00</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Tassel Loafers Black</p>
									<p class="item-brand">ASOS</p>
									<p class="item-merchant">ASOS</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="https://www.hollisterco.com/shop/us/p/hollister-slim-straight-jeans-7503124_01?source=googleshopping&locale=en&country=US&cmp=PLA_621827326_354760641_29579767521_166157250246_c_pla_online&gclid=CMHW8KD15NMCFQ94fgodqdcHnw">
								<img class="img-rounded avatar" src="img/sample/3.3.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="https://www.hollisterco.com/shop/us/p/hollister-slim-straight-jeans-7503124_01?source=googleshopping&locale=en&country=US&cmp=PLA_621827326_354760641_29579767521_166157250246_c_pla_online&gclid=CMHW8KD15NMCFQ94fgodqdcHnw">
								<button type="button" class="btn btn-sm btn-success buy-button">$25</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Slim Straight Jeans</p>
									<p class="item-brand">Epic Flex</p>
									<p class="item-merchant">Hollister</p>
								</div>
							</div>
						</li>
						<li class="product-item">
							<a class="pull-left" target="_blank" href="http://www.forever21.com/Product/Product.aspx?Br=21MEN&Category=mens-main&ProductID=2000213132&VariantID=03&gclid=CJWSxZn15NMCFcVlfgodHzsHqA">
								<img class="img-rounded avatar" src="img/sample/3.4.jpg" alt="item">
							</a>
							<a class="pull-right" target="_blank" href="http://www.forever21.com/Product/Product.aspx?Br=21MEN&Category=mens-main&ProductID=2000213132&VariantID=03&gclid=CJWSxZn15NMCFcVlfgodHzsHqA">
								<button type="button" class="btn btn-sm btn-success buy-button">$12.53</button>
							</a>
							<div class="product-item-body"> <!-- Item Name, Merchant, Brand, Price --> 
								<div class="product-item-details">
									<p class="item-name">Distressed Longline Tee</p>
									<p class="item-brand">Forever 21</p>
									<p class="item-merchant">Forever 21</p>
								</div>
							</div>
						</li>
					</ul>
				</div> <!-- End DFL post footer --> 
			</div> <!-- End DFL Post --> 

		</div> <!-- End Post -->
	</div> <!-- End Column --> 
	<!--============== End Post =========================--> 
</div> <!-- End  Row --> 