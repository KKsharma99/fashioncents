<?php

if(!defined('INCLUDE_CHECK')) {
	header("Location: 404.php");
	exit();
}
include('header.php');
session_start();

include('connect.php');

if (!isset($_SESSION['id'])) {
	$_SESSION = array();
	$_SESSION['id'] = 0;
}
if (empty($_SESSION['id'])) {
	include('guestnav.php');
	include('guestprompt.php');
} else {
	include('nav.php');
}
