<?php 
function createPost() {
  if (isset($_SESSION['id']) && $_SESSION['id'] != -1) {
    mysqli_query($GLOBALS['sqllink'], "INSERT INTO tbl_posts(userid,description,posttime)
      VALUES(
      '" . $_SESSION['id'] . "',
      '" . mysqli_real_escape_string($GLOBALS['sqllink'], $_POST['desc']) . "',
      '".time()."'
      )"
      );
    if (mysqli_error($GLOBALS['sqllink']) == "") {
      $newpost = mysqli_fetch_assoc(mysqli_query($GLOBALS['sqllink'],"SELECT LAST_INSERT_ID() FROM tbl_posts"));
      //var_dump($newpost);
      $newpost = $newpost['LAST_INSERT_ID()'];
      $imagename = saveImage($newpost);
      mysqli_query($GLOBALS['sqllink'], "UPDATE tbl_posts SET image_small='" . $imagename . "' WHERE postid= " .$newpost);
      for($i = 1; $i <= ((int)$_POST['itemcount']); $i++) {
        $_POST['amazon'.$i] = urldecode($_POST['amazon'.$i]);
        $_POST['amazon'.$i] = mysqli_real_escape_string($GLOBALS['sqllink'], $_POST['amazon'.$i]);
        $query= "INSERT INTO `tbl_items`(`postid`, `itemname`, `brand`, `price`, `link`) VALUES('".$newpost."','".$_POST['item'.$i]."','".$_POST['brand'.$i]."','".$_POST['price'.$i]."','".$_POST['amazon'.$i]."')";
        //echo $query;
        mysqli_query($GLOBALS['sqllink'],$query);

      }
          //sets first post to profile pic if its not set
      $sql = "SELECT profilepic FROM tbl_masterusers WHERE userid = " . $_SESSION['id'];
      $pic = mysqli_fetch_assoc(mysqli_query($GLOBALS['sqllink'], $sql));
      if ($pic == null || $pic == 'img/users/defaultuser.png') {
        $updatesql = "UPDATE tbl_masterusers SET profilepic = '" . $imagename . "' WHERE userid = " . $_SESSION['id'];
        mysqli_query($GLOBALS['sqllink'], $updatesql);
      }
      return $newpost;
    }

  }
}
function saveImage($id) {
    //Stores the filename as it was on the client computer.
  $imagename = $id . "_small.png";
  $imagenameL = $id . "_large.png";
    //Stores the filetype e.g image/jpeg
  $imagetype = $_FILES['image']['type'];
    //Stores any error codes from the upload.
  $imageerror = $_FILES['image']['error'];
    //Stores the tempname as it is given by the host when uploaded.
  $imagetemp = $_FILES['image']['tmp_name'];
    //The path you wish to upload the image to
  $imagePath = "img/posts/";
  if(is_uploaded_file($imagetemp)) {
    compress_image($imagetemp, $imagePath.$imagenameL, 100);
    return compress_image($imagetemp, $imagePath.$imagename, 60);
  }
  else {
    echo "Failed to upload your image.";
  }
}

function compress_image($source_url, $destination_url, $quality) {

  $info = getimagesize($source_url);

  if ($info['mime'] == 'image/jpeg')
    $image = imagecreatefromjpeg($source_url);

  elseif ($info['mime'] == 'image/gif')
    $image = imagecreatefromgif($source_url);

  elseif ($info['mime'] == 'image/png')
    $image = imagecreatefrompng($source_url);

  imagejpeg($image, $destination_url, $quality);
  return $destination_url;
}
?>