<!-- SORT BUTTON ON MOBILE --> 
<?php if(strpos($_SERVER['REQUEST_URI'],'index.php') !== false) { ?>
<button type="button" id="fixedsort" onclick="openNav()" class="btn btn-md fixed-sort-btn visible-xs">
  <img height="25px" style="margin-top:5px; margin-bottom:5px" src="vendor/custom-icons/funnel-white.png">
</button>
<?php } ?>

<!-- SORTING PANEL -->
<form method="GET" action="index.php"> 
<div id="sortpanel" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <br>
  <br> 

  <div style="padding-left:15px; padding-right:15px; color: white;"> 
    <div class="text-left"> 
    <h2>SORT</h2>
    </div> 

    <h3>Gender</h3>

    <div class="control-group" name="gender" id="genderradio">
      <label class="control control--radio">All
        <input type="radio" name="gender" value="All" checked="checked">
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Male
        <input type="radio" name="gender" value="Male"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Female
        <input type="radio" name="gender" value="Female"/>
        <div class="control__indicator"></div>
      </label>
    </div>

    <h3>Type</h3>

    <div class="control-group" name="type" id="genderradio">
      <label class="control control--radio">All
        <input type="radio" name="type" value="All" checked="checked"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Community
        <input type="radio" name="type" value="Community"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Celebrity
        <input type="radio" name="type" value="Celebrity"/>
        <div class="control__indicator"></div>
      </label>
    </div>


    <h3>Outfit Category</h3>
    
    <label class="control control--checkbox">Formal
      <input type="checkbox" name = "category1" value="Formal"/>
      <div class="control__indicator"></div>
    </label>
    <label class="control control--checkbox">Casual
      <input type="checkbox" name = "category2" value="Casual"/>
      <div class="control__indicator"></div>
    </label>


    <h3>Feed Type</h3>
    
    <div class="control-group" name = "feed">
      <label class="control control--radio">Newest
        <input type="radio" name="feed" value="Newest" checked="checked"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Featured
        <input type="radio" name="feed" value="Featured"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Popular This Week
        <input type="radio" name="feed" value="PopularWeek"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Popular This Month
        <input type="radio" name="feed" value="PopularMonth"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Popular This Year
        <input type="radio" name="feed" value="PopularYear"/>
        <div class="control__indicator"></div>
      </label>
      <label class="control control--radio">Popular All Time
        <input type="radio" name="feed" value="PopularAll"/>
        <div class="control__indicator"></div>
      </label>
    </div>

  </div>
  <br> 
  <div class="text-center"> 
    <button class="btn btn-md smoothbutton btn-secondary" style="margin-bottom:25px;">SUBMIT</button>
    <br> 
  </div>

</div> <!-- End Inner Sort Panel --> 
</form>
<!-- The Script Below Opens the Sorting Panel --> 

<script>
  function openNav() {
    document.getElementById("sortpanel").style.width = "250px";
  }

  function closeNav() {
    document.getElementById("sortpanel").style.width = "0";
  }
</script>