<script type="text/javascript">
	
function follow(c, a, b) {
	$.ajax({
		url: 'followuser.php',
		type: 'post',
		data: {uid: c, id: a, status: b},
		success: function(data) {
			var follownames = document.getElementsByName("follow".concat(a));
      		var followlist = Array.prototype.slice.call(follownames);
			if (data == "1") {
				for ( var count = 0; count < followlist.length; count++) {
      				followlist[count].src = 'vendor/custom-icons/circle-check.png';
      				followlist[count].setAttribute("onclick", "follow(" + c + ", " + a + ", 2);");
      			}
			} else
			if (data == "2") {
				for( var count = 0; count < followlist.length; count++) {
      				followlist[count].src = "vendor/custom-icons/circle-plus.png";
      				followlist[count].setAttribute("onclick", "follow(" + c + ", " + a + ", 1);");
      			}
			}
		}
	})
}

function save(a, b, c) {
	$.ajax({
		url: 'savepost.php',
		type: 'post',
		data: {postid: a, status:b, uid: c},
		success: function(data) {
			var loc = document.getElementById("save".concat(a));
			if (data == "1") {
				loc.src = 'vendor/custom-icons/bookmark-active.png';
				loc.setAttribute("onclick", "save(" + a + ", 2, " + c + ");");
			} else
			if (data == "2") {
				loc.src = 'vendor/custom-icons/bookmark.png';
				loc.setAttribute("onclick", "save(" + a + ", 1" + c + ");");
			}
		}
	})
}

function like(a, b, c) {
	$.ajax({
		url: 'likepost.php',
		type: 'post',
		data: {postid: a, status:b, uid: c},
		success: function(data) {
			var loc = document.getElementById("like".concat(a));
			var likes = document.getElementById("likebox".concat(a));
			var imgloc = document.getElementById("img".concat(a));
			var numlikes = $('#likebox'.concat(a)).children().html();
			if (data == "1") {
				loc.src = 'vendor/custom-icons/heart2.png';
				loc.setAttribute("onclick", "like(" + a + ", 2, " + c + ");");
				imgloc.removeAttribute("ondblclick");
				numlikes++;
				$('#likebox'.concat(a)).children().html(numlikes);
				likes.setAttribute("data-original-title", numlikes + " Likes").html();
			} else
			if (data == "2") {
				loc.src = 'vendor/custom-icons/heart.png';
				loc.setAttribute("onclick", "like(" + a + ", 1," + c + ");");
				imgloc.setAttribute("ondblclick", "like(" + a + ", 1," + c + ");");
				numlikes--;
				$('#likebox'.concat(a)).children().html(numlikes);
				likes.setAttribute("data-original-title", numlikes + " Likes").html();
			}
			
		}
	})
}
function commentlike(a, b, c) {
	$.ajax({
		url: 'likecomment.php',
		type: 'post',
		data: {commentid: a, status:b, uid: c},
		success: function(data) {
			var loc = document.getElementById("comment".concat(a));
			//var likes = document.getElementById("commentcount".concat(a));
			var numlikes = $('#commentcount'.concat(a)).html();
			if (data == "1") {
				loc.src = 'vendor/custom-icons/heart2.png';
				loc.setAttribute("onclick", "commentlike(" + a + ", 2, " + c + ");");
				numlikes++;
				$('#commentcount'.concat(a)).html(numlikes);
			} else
			if (data == "2") {
				loc.src = 'vendor/custom-icons/heart.png';
				loc.setAttribute("onclick", "commentlike(" + a + ", 1," + c + ");");
				numlikes--;
				$('#commentcount'.concat(a)).html(numlikes);
			}
			
		}
	})
}
function comment(a, b) {
	var commentbox = document.getElementById("commentbox".concat(a));
	if (commentbox.value != "") {
		var text = commentbox.value;
		commentbox.value = "";
		$.ajax({
			url: 'addcomment.php',
			type: 'post',
			data: {postid: a, uid: b, comment: text},
			success: function(data) {
				$('#commentlist' + a).append(data);
			}
		})
	}
}
function deletepost(a) {
	$.ajax({
		url: 'deletepost.php',
		type: 'post',
		data: {postid: a},
		success: function(data) {
			if (data == 1) {
				$('#post'.concat(a)).remove();
				hideDeleteModal();
			}
		}
	})
}

</script>
